#include "llista.hpp"

void Llista::inverteix() {
    node *p = _prim->seg;  // Comenzamos en el primer nodo real (suponiendo que _prim es el nodo fantasma)
    while (p != _prim) {
        node *temp = p->seg;  // Guardamos el enlace original al siguiente nodo.
        p->seg = p->ant;      // Intercambiamos seg y ant.
        p->ant = temp;
        p = temp;             // Avanzamos al siguiente nodo (el original p->seg).
    } 
        // Ahora, invertir los punteros del nodo fantasma.
    node *temp = _prim->seg;
    _prim->seg = _prim->ant;
    _prim->ant = temp;
}

