#include "llista.hpp"
void Llista::duplica_parells_elimina_senars() {
    node *p = _prim;

    while (p != nullptr) {
        if (p->info % 2 == 0) { // Si el nodo es par
            node *nuevo = new node;
            if (nuevo == nullptr) {
                // Manejo de error en la asignación de memoria
                return;
            }
            nuevo->info = p->info; // Copiar el valor
            nuevo->ant = p; // Establecer el anterior como el nodo actual

            // Establecer el siguiente nodo
            nuevo->seg = p->seg; 
            p->seg = nuevo; // Enlazar el nuevo nodo en la lista

            // Si no hay siguiente, actualizar el último
            if (nuevo->seg != nullptr) {
                nuevo->seg->ant = nuevo; // Actualizar el anterior del siguiente
            } else {
                _ult = nuevo; // Si es el último nodo, actualizar _ult
            }

            p = nuevo->seg; // Mover a p al siguiente nodo
            _long++; // Aumentar el tamaño de la lista

        } else { // Si el nodo es impar
            node *elim = p; // Guardar el nodo a eliminar
            if (p->ant == nullptr) { // Si es el primer nodo
                _prim = p->seg; // Mover el primer nodo
                if (_prim != nullptr) {
                    _prim->ant = nullptr; // Actualizar el anterior del nuevo primero
                }
            } else {
                p->ant->seg = p->seg; // Enlazar el anterior al siguiente
            }

            if (p->seg != nullptr) {
                p->seg->ant = p->ant; // Enlazar el siguiente al anterior
            } else {
                _ult = p->ant; // Actualizar el último si se elimina el último nodo
            }

            p = p->seg; // Mover p al siguiente nodo
            delete elim; // Eliminar el nodo
            _long--; // Decrementar el tamaño de la lista
        }
    }
}


